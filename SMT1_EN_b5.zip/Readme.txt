1. What you need:
	1) A GBA rom of Shin Megami Tensei 1 (Japanese version), e.g., "Shin Megami Tensei (Japan).gba"
	2) An iOS rom Shin Megami Tensei 1 (English version), e.g., "Shin Megami Tensei (ENG) v1.0.0.ipa"
	3) A BPS patch tool, e.g., Floating IPS

2. Apply the patches:
	1) Open the iOS rom ("Shin Megami Tensei (ENG) v1.0.0.ipa") using a decompression software such as 7-Zip.
	2) Extract the "megaten1" file (no file extension) from Payload\megaten1.app
	3) Apply the patch "SMT1_1_gba.bps" to the gba rom ("Shin Megami Tensei (Japan).gba"), with Floating IPS. Save the newly generated file as SMT1_1_gba.gba
	4) Apply the patch "SMT1_2_ios.bps" to the "megaten1" file with Floating IPS. Save the newly generated file as SMT1_2_ios.gba (by default it will be saved as SMT1_2_ios.bps)
	5) Put the batch file SMT1_create.bat (or SMT1_create.sh for Unix/Linux/Mac systems) in the same folder as SMT1_1_gba.gba and SMT1_2_ios.gba, and execute it
	6) You will obtain SMT1_new.gba, which is the translated rom
	
Note: This is currently a preliminary patch, which only translates main dialogues, demon negotiations, and A-MODE DDS contents.

11/06/2020
by gymzatan