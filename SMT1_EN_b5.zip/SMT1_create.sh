#!/bin/bash

cat SMT1_1.gba SMT1_2.gba > SMT1_new.gba